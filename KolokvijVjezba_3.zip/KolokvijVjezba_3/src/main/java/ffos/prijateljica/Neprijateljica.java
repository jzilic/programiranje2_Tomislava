/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.prijateljica;

import java.util.Date;

/**
 *
 * @author Jure
 */
class Neprijateljica {

    public int sifra;
    public boolean introvertno;
    public String suknja;
    public float euro;
    public String majica;
    public Date treciPut;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public boolean isIntrovertno() {
        return introvertno;
    }

    public void setIntrovertno(boolean introvertno) {
        this.introvertno = introvertno;
    }

    public String getSuknja() {
        return suknja;
    }

    public void setSuknja(String suknja) {
        this.suknja = suknja;
    }

    public float getEuro() {
        return euro;
    }

    public void setEuro(float euro) {
        this.euro = euro;
    }

    public String getMajica() {
        return majica;
    }

    public void setMajica(String majica) {
        this.majica = majica;
    }

    public Date getTreciPut() {
        return treciPut;
    }

    public void setTreciPut(Date treciPut) {
        this.treciPut = treciPut;
    }

}
